public class Introducer{

  //method to introduce human
  public String createPublicIntroduction(Human person){
    
    //introductory sentence
    String introduction = "I am pleased to introduce " + person.getFirstName() + ". ";

    //male sentences
      if(person.gender == Gender.MALE){
      introduction += "He is " + person.calculateCurrentAgeInYears() + " years old. ";
    try{
      if(person instanceof Adult){
        introduction += "He is a " + ((Adult)person).getOccupation() + " at " + ((Adult)person).getPlaceOfWork() + ". ";
        }
      }catch(Exception invalid){
          System.out.println("Error! Please ensure all Adult fields are correct!");
      }
    try{
      if(person instanceof Youth){
        introduction += "He is in grade " + ((Youth)person).getSchoolGrade() + " and goes to " + ((Youth)person).getSchoolName() + ". ";
      }
    }
    catch(Exception invalid1){
      System.out.println("Error! Please ensure all Youth fields are correct!");
    }
    try{
    if(person instanceof HenryWiseWoodStudent){
      introduction += "He belongs to " + ((HenryWiseWoodStudent)person).getHomeRoomTeacher() + "'s homeroom, which is" + ((HenryWiseWoodStudent)person).getHomeRoom() + ".";
    }
      }
    catch(Exception invalid2){
      System.out.println("Error! Please ensure all HenryWiseWoodStudent fields are correct!");
    }
        }
    //female sentences
    if(person.gender == Gender.FEMALE){
      introduction += "She is " + person.calculateCurrentAgeInYears() + " years old. ";
    try{
      if(person instanceof Adult){
        introduction += "She is a " + ((Adult)person).getOccupation() + " at " + ((Adult)person).getPlaceOfWork() + ". ";
        }
      }catch(Exception invalid){
          System.out.println("Error! Please ensure all Adult fields are correct!");
      }
    try{
      if(person instanceof Youth){
        introduction += "She is in grade " + ((Youth)person).getSchoolGrade() + " and goes to " + ((Youth)person).getSchoolName() + ". ";
      }
    }
    catch(Exception invalid1){
      System.out.println("Error! Please ensure all Youth fields are correct!");
    }
    try{
    if(person instanceof HenryWiseWoodStudent){
      introduction += "She belongs to " + ((HenryWiseWoodStudent)person).getHomeRoomTeacher() + "'s homeroom, which is " + ((HenryWiseWoodStudent)person).getHomeRoom() + ".";
    }
      }
    catch(Exception invalid2){
      System.out.println("Error! Please ensure all HenryWiseWoodStudent fields are correct!");
    }
  }
    return introduction;
}
}