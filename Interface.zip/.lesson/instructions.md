# Introduction:

Now that we have our Humans classes working, we want to extend their functionality to allow the sorting of Human. This may sound sinister, but it is not. We merely want to be able to sort Humans based on a given attribute. That is, given two Humans (A and B), we want to be able to determine if "A < B", "A == B", or "A > B". Now, just like with real Humans, you may say that there are many different ways to sort Humans. This is entirely true, and you will therefore provide three different comparisons.

Our premise is that we wish to create a database that contains all the Humans in our school. You can then easily imagine that we may need to sort these Human in various ways. In one "use" case, imagine that we want to find all students under the age of eighteen. In this case, we simply sort by age; in a second use case, we may want to have a list of the names of all students, and we thus need to sort by last name and then first name. A third "use" case may call for the creation of a seating plan for the graduation assembly, which groups by type of Human first (students get to sit in the back, teachers in the front), and then by name.

## Interfaces

There are two mechanisms in Java to allow you to specify a sort order for objects of type Human.  

1. A default order can be specified by having your Humans class implement the Comparable interface.
2. Different orders can be specified by creating a new Comparator/Human/ object. These are objects that must provide a method.
  - Comparators should by convention be included as public static variables (i.e. constants) in your Human class, as they "belong" to the definition of Humans, and cannot be changed at run time.
  - That said, you could also create these in any other location, such as in the Introducer class.
  - Although the syntax is slightly different, this is still ultimately implementing an interface.

See https://docs.oracle.com/javase/tutorial/collections/interfaces/order.html for a detailed explanation.

# Assignment
Implement the unit test on repl.it. This test is designed to run in your Humans project, with a modified Humans class that will allow Humans to be "compared". 

- AGE_ORDER, which orders from oldest to youngest based on birthYear, birthMonth, and birthDay.
- NAME_ORDER will order lexiographically by lastName and then firstName.
- ASSEMBLY_ORDER will order by type (HenryWiseWoodStudent < Youth < Adult < Human) and then by NAME_ORDER.

You will do so by implementing the Comparable interface (thus allowing a Human to compare itself to another) and also by providing three public static variables in the Humans class that contain an object of type Comparator/Human/. The default comparator (and thus the one that the Comparable interface implements) is AGE_ORDER.

**Note:**
- You may prefer to implement the Comparators in a separate class to keep your code looking nice and clean. Ensure that you submit all of your files in that case.
- It may interest you to know that the native sort method used by ArrayList (which it inherits from List) is a "stable, adaptive, iterative mergesort". See the API definition.
  
  