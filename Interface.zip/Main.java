class Main {
  public static void main(String[] args) {
    //Do not write code here unless testing your objects. Upload your files from the previous assignment to use for this assignment.

    //tests
    Introducer introducer = new Introducer();

    System.out.println("\n");
    
    Human person = new Human(2004, 01, 24, "John","Doe",Gender.MALE);
String intro1 = introducer.createPublicIntroduction(person);
System.out.println(intro1);

    System.out.println("\n");

    Human student = new HenryWiseWoodStudent(2004, 03, 14, "Jenny", "Smith", Gender.FEMALE, 12, 105, "McGill");
    String intro2 = introducer.createPublicIntroduction(student);
System.out.println(intro2);
  }
}