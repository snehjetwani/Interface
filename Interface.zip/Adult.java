public class Adult extends Human{
  
  //instances
  String placeOfWork;
  String occupation;

  //constructor method
  public Adult(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender, String placeOfWork, String occupation){
    super(birthYear, birthMonth, birthDay, firstName, lastName, gender);
    this.placeOfWork = placeOfWork;
    this.occupation = occupation;
  }

  //getter methods
  public String getPlaceOfWork(){
    return placeOfWork;
  }
  public String getOccupation(){
    return occupation;
  }

  //setter methods
  public void setPlaceOfWork(String placeOfWork){
    this.placeOfWork = placeOfWork;
  }
  public void setOccupation(String occupation){
    this.occupation = occupation;
  }
}