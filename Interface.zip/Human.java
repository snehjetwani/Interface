//imports
import java.time.Month;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;

//Human class
public class Human implements Comparable<Human>{
 
  //instances
  final int birthYear;
  final int birthMonth;
  final int birthDay;
  String firstName;
  String lastName;
  Gender gender;

  //constructor
  public Human(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender){
    this.birthYear = birthYear;
    this.birthMonth = birthMonth;
    this.birthDay = birthDay;
    this.firstName = firstName;
    this.lastName = lastName;
    this.gender = gender;
  }
  
  //getter methods
  public int getBirthYear(){
    return birthYear;
  }
  public int getBirthMonth(){
    return birthMonth;
  }
  public int getBirthDay(){
    return birthDay;
  }
  public String getFirstName(){
    return firstName;
  }
  public String getLastName(){
    return lastName;
  }
  public Gender getGender(){
    return gender;
  }

  //setter methods
  public void setFirstName(String firstName){
    this.firstName = firstName;
  }
  public void setLastName(String lastName){
    this.lastName = lastName;
  }
  public void setGender(Gender gender){
    this.gender = gender;
  }
  
  //method to calculate current age in years
  public int calculateCurrentAgeInYears(){
    LocalDate currentDate = LocalDate.now();
    LocalDate birthday = LocalDate.of(birthYear, birthMonth, birthDay);
    Period age = Period.between(birthday, currentDate);
    return age.getYears();
  }

  //method to return birthday
  public LocalDate Birthday(){
    LocalDate birthday = LocalDate.of(birthYear, birthMonth, birthDay);
    return birthday;
  }

  //default age comparator
  public int compareTo(Human person){
    return Birthday().compareTo(person.Birthday());
  }

  //order persons by age
  public static Comparator<Human> AGE_ORDER = new Comparator<Human>(){
    public int compare(Human person, Human person1){
      return person.Birthday().compareTo(person1.Birthday());
    }
  };

  //orders persons by full name
  public static Comparator<Human> NAME_ORDER = new Comparator<Human>(){
    public int compare(Human person, Human person1){
      return (person.getLastName() + person.getFirstName()).compareTo(person1.getLastName() + person1.getFirstName());
    }
  };

  //orders persons by assembly
  public static Comparator<Human> ASSEMBLY_ORDER = new Comparator<Human>(){
    public int compare(Human person, Human person1){
      String comparePerson = "";
      String comparePerson1 = "";
      if (person instanceof HenryWiseWoodStudent){
        comparePerson += "A";
      }
      else if (person instanceof Youth){
        comparePerson += "B";
      }
      else if (person instanceof Adult){
        comparePerson += "C";
      }
      else if (person instanceof Human){
        comparePerson += "D";
      }
      if (person1 instanceof HenryWiseWoodStudent){
        comparePerson1 += "A";
      }
      else if (person1 instanceof Youth){
        comparePerson1 += "B";
      }
      else if (person1 instanceof Adult){
        comparePerson1 += "C";
      }
      else if (person1 instanceof Human){
        comparePerson1 += "D";
    }
      return (comparePerson + person.getLastName() + person.getFirstName()).compareTo(comparePerson1 + person1.getLastName() + person1.getFirstName());
  }
};
}