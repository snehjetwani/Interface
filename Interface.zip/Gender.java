public enum Gender {
  //Add to this as you need to
    MALE, FEMALE;
}
